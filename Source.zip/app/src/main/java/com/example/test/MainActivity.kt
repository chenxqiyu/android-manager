package com.chenx.taskmgr

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import com.example.test.util.ImageUtils
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role.Companion.Button
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.AlertDialog
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.asImageBitmap
import com.chenx.taskmgr.ui.theme.TestTheme
import com.example.test.db.User
import com.example.test.util.ImageUtils.saveImageToGallery
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private val REQUEST_CODE = 1
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 检查Shizuku服务是否可用
        if (Shizuku.pingBinder()) {
            // 检查是否已有权限
            if (Shizuku.isPreV11() || Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                // 已有权限，继续执行
                initializeUI()
            } else {
                // 请求权限
                Shizuku.requestPermission(REQUEST_CODE)
            }
        } else {
            // Shizuku服务不可用
            Toast.makeText(this, "请先启动Shizuku服务,并授权应用", Toast.LENGTH_LONG).show()
            initializeUI()
        }
    }
    
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 权限已授予
                initializeUI()
            } else {
                // 权限被拒绝
                Toast.makeText(this, "需要Shizuku权限才能执行操作", Toast.LENGTH_LONG).show()
                initializeUI()
            }
        }
    }
    
    private fun initializeUI() {
        enableEdgeToEdge()
        setContent {
            TestTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    UserList(
                        modifier = Modifier.padding(innerPadding),
                        context = this
                    )
                }
            }
        }
    }
}

@Composable
fun ProcessInfoTable(processInfo: String, modifier: Modifier = Modifier, context: ComponentActivity = LocalContext.current as ComponentActivity) {
    val imageUtils = ImageUtils
    val lines = processInfo.split("\n").filter { it.isNotBlank() }
    val scope = rememberCoroutineScope()
    var showConfirmDialog by remember { mutableStateOf(false) }
    var selectedPid by remember { mutableStateOf("") }
    var selectedName by remember { mutableStateOf("") }
    val packageManager = context.packageManager
    
    // 创建一个可控制的滚动状态
    val listState = rememberLazyListState()
    
    // 当processInfo更新时，滚动到顶部
    LaunchedEffect(processInfo) {
        if (lines.isNotEmpty()) {
            listState.animateScrollToItem(0)
        }
    }

    if (lines.isEmpty()) {
        return
    }
    
    val headers = lines.first().split("\\s+".toRegex())
    val dataRows = lines.drop(1)
    
    // 获取应用图标的函数
    fun getAppIconFromPackageName(packageName: String): Bitmap? {
        return try {
            val applicationInfo = packageManager.getApplicationInfo(packageName, 0)
            val drawable = packageManager.getApplicationIcon(applicationInfo)
            val bitmap = Bitmap.createBitmap(drawable.intrinsicWidth, drawable.intrinsicHeight, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            bitmap
        } catch (e: Exception) {
            null
        }
    }
    
    Column(modifier = modifier.fillMaxWidth()) {
        // 表头
        Row(modifier = Modifier.fillMaxWidth()) {
            headers.forEach { header ->
                if (header.isNotBlank()) {
                    Text(
                        text = when(header) {
                            "PID" -> "进程"
                            "pid" -> "进程"
                            "USER" -> "用户"
                            "user" -> "用户"
                            "%CPU" -> "CPU"
                            "%cpu" -> "CPU"
                            "%MEM" -> "内存"
                            "%mem" -> "内存"
                            "COMMAND" -> "命令"
                            "CMD" -> "命令"
                            "cmd" -> "命令"
                            "NAME" -> "命令"
                            "name" -> "命令"
                            else -> header
                        },
                        modifier = Modifier
                            .weight(if (header == "COMMAND" || header == "CMD" || header == "cmd" || header == "NAME" || header == "name") 3f else 0.8f)
                            .height(32.dp),
                        textAlign = TextAlign.Start
                    )
                }
            }
//            Text(
//                text = "操作",
//                modifier = Modifier
//                    .weight(1f)
//                    .height(32.dp)
//                    .padding(horizontal = 4.dp),
//                textAlign = TextAlign.Start
//            )
        }
        Divider()
        
        // 数据行
        LazyColumn(state = listState) {
            items(dataRows) { row ->
                val cells = row.split("\\s+".toRegex()).map { it.trim() }.filter { it.isNotBlank() }
                val packageName = cells.lastOrNull() ?: ""
                val appIcon = remember(packageName) { getAppIconFromPackageName(packageName) }
                
                Row(modifier = Modifier.fillMaxWidth()) {
                    // 显示进程信息
                    Row(modifier = Modifier
                        .weight(1f)
                        // 为行添加足够的高度以适应多行文本
                        .padding(vertical = 4.dp)) {
                        // 单元格权重在下面根据列类型动态分配
                        cells.forEachIndexed { index, cell ->
                            // 根据CPU和内存使用率设置不同的颜色
                            val color = when {
                                // 检查是否为CPU列（第3列，索引2）
                                index == 2 && cell.replace("%", "").toFloatOrNull() != null -> {
                                    val cpuValue = cell.replace("%", "").toFloat()
                                    when {
                                        cpuValue > 50 -> androidx.compose.ui.graphics.Color.Red
                                        cpuValue > 20 -> androidx.compose.ui.graphics.Color(0xFFFF6D00) // 橙色
                                        cpuValue > 10 -> androidx.compose.ui.graphics.Color(0xFFFFB300) // 黄色
                                        else -> androidx.compose.ui.graphics.Color(0xFF4CAF50) // 绿色
                                    }
                                }
                                // 检查是否为内存列（第4列，索引3）
                                index == 3 && cell.replace("%", "").toFloatOrNull() != null -> {
                                    val memValue = cell.replace("%", "").toFloat()
                                    when {
                                        memValue > 20 -> androidx.compose.ui.graphics.Color.Red
                                        memValue > 10 -> androidx.compose.ui.graphics.Color(0xFFFF6D00) // 橙色
                                        memValue > 5 -> androidx.compose.ui.graphics.Color(0xFFFFB300) // 黄色
                                        else -> androidx.compose.ui.graphics.Color(0xFF4CAF50) // 绿色
                                    }
                                }
                                else -> MaterialTheme.colorScheme.onSurface
                            }
                            
                            // 为命令列（最后一列）分配更多权重
                            val cellWeight = when {
                                // 如果是最后一列（命令列），给予更多权重
                                index == cells.size - 1 -> 3f
                                // 其他列使用较小的权重
                                else -> 1.5f
                            }
                            
                            Text(
                                text = if (index == 2 || index == 3) "$cell%" else cell,
                                modifier = Modifier
                                    .weight(cellWeight)
                                    .padding(horizontal = 2.dp)
                                    .clickable {
                                        if (index == cells.size - 1) {
                                            val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("package_name", cell)
                                            clipboardManager.setPrimaryClip(clip)
                                            Toast.makeText(context, "已复制包名: $cell", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                textAlign = TextAlign.Start,
                                // 命令列和用户列允许多行显示，其他列保持单行
                             //   maxLines = if (index == cells.size - 1 || index == 1) Int.MAX_VALUE else 1,
                                // 只有命令列和用户列不使用省略号
                               // overflow = if (index == cells.size - 1 || index == 1) androidx.compose.ui.text.style.TextOverflow.Visible else androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                color = color
                            )
                        }
                    }
                    
                    // 根据是否有图标决定显示图标按钮还是文本按钮
                    Box(modifier = Modifier.weight(0.3f).height(96.dp), contentAlignment = Alignment.Center) {
                        if (appIcon != null) {
                            // 显示图标按钮
                            Button(
                                onClick = {
                                    selectedPid = cells.firstOrNull() ?: ""
                                    selectedName = cells.lastOrNull() ?: ""
                                    showConfirmDialog = true
                                },
                                modifier = Modifier
                                    .padding(8.dp)
                                    .fillMaxSize(),
                            ) {
                                androidx.compose.foundation.Image(
                                    bitmap = appIcon.asImageBitmap(),
                                    contentDescription = "结束",
                                    modifier = Modifier.size(96.dp)
                                )
                            }
                        } else {
                            // 显示文本按钮
                            Button(
                                onClick = {
                                    selectedPid = cells.firstOrNull() ?: ""
                                    selectedName = cells.lastOrNull() ?: ""
                                    showConfirmDialog = true
                                },
                                modifier = Modifier
                                    .padding(8.dp)
                                    .fillMaxSize(),
                            ) {
                                Text("结束", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
                Divider()
            }
        }
        
        // 将确认对话框移到LazyColumn外部
        if (showConfirmDialog) {
            val currentAppIcon = remember(selectedName) { getAppIconFromPackageName(selectedName) }
            AlertDialog(
                onDismissRequest = { showConfirmDialog = false },
                title = { Text("确认结束进程") },
                text = { 
                    Column {
                        Text("确定要结束以下进程吗？")
                        if (currentAppIcon != null) {
                            Image(
                                bitmap = currentAppIcon.asImageBitmap(),
                                contentDescription = "应用图标",
                                modifier = Modifier.size(72.dp)
                            )
                        }
                        Text("进程ID: $selectedPid")
                        Text("命令: $selectedName")
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            scope.launch {
                                try {
                                    if (Shizuku.pingBinder()) {
                                        //Shizuku.newProcess()
                                        //am force-stop com.chenx.taskmgr

                                        //ps -p 31748 -o NAME=
                                        var result = Shizuku.newProcess(arrayOf("ps", "-p", selectedPid,"-o","NAME="), null, null).inputStream.bufferedReader().use { it.readText() }
                                        var selectedName2: String= result.toString().trim();

                                         Shizuku.newProcess(arrayOf("am", "force-stop", selectedName2), null, null)


                                        Shizuku.newProcess(arrayOf("kill", "-9", selectedPid), null, null)
                                        Toast.makeText(context, "已成功结束进程: $selectedPid (命令: $selectedName2)", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "请先启动Shizuku服务", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(context, "结束进程失败: ${'$'}{e.message}", Toast.LENGTH_SHORT).show()
                                }
                                showConfirmDialog = false
                            }
                        }
                    ) {
                        Text("确认")
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { showConfirmDialog = false }
                    ) {
                        Text("取消")
                    }
                }
            )
        }
    }
}

@Composable
fun UserList(modifier: Modifier = Modifier, context: ComponentActivity) {
 //   var users by remember { mutableStateOf<List<User>>(emptyList()) }
    var dbPath by remember { mutableStateOf("") }
    var initialSortByCpu by remember { mutableStateOf(true) }
    
    LaunchedEffect(Unit) {
        dbPath = context.getDatabasePath("app_database").absolutePath
    }
    var processInfo by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
       // val db = AppDatabase.getDatabase(context)

//        // 初始化测试数据
//        val testUsers = listOf(
//            User(name = "张三", age = 25),
//            User(name = "李四", age = 30),
//            User(name = "王五", age = 28)
//        )
//
//        // 插入测试数据
//        testUsers.forEach { user ->
//            db.userDao().insertUser(user)
//        }
        
        // 获取所有用户
       // users = db.userDao().getAllUsers()
        
        // 初始按CPU排序
        if (initialSortByCpu && Shizuku.pingBinder()) {
            try {
                //ps -eo pid,user,%cpu,%mem,cmd | sort -k4 -nr | head -20
                val result = Shizuku.newProcess(arrayOf("ps","-eo", "pid,user,%cpu,%mem,name", "--sort=-%cpu"), null, null).inputStream.bufferedReader().use { it.readText() }
                processInfo = result
            } catch (e: Exception) {
                processInfo = "获取CPU信息失败: ${e.message}"
            }
        }
    }

   
    
    Column(
    modifier = modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
) {
//        Text("数据库位置: $dbPath", modifier = Modifier.padding(16.dp))
        val scope = rememberCoroutineScope()

        var pidInput by remember { mutableStateOf("") }
        var showQRDialog by remember { mutableStateOf(false) }
    var showShizukuDialog by remember { mutableStateOf(false) }



        // PID控制区域
//        Row {
//            TextField(
//                value = pidInput,
//                onValueChange = { pidInput = it },
//                label = { Text("输入PID") },
//                modifier = Modifier.padding(16.dp)
//            )
//
//            Button(
//                onClick = {
//                    scope.launch {
//                        try {
//                            if (Shizuku.pingBinder()) {
//                                if (pidInput.isNotBlank()) {
//                                    val result = Shizuku.newProcess(arrayOf("kill", "-9", pidInput), null, null).inputStream.bufferedReader().use { it.readText() }
//                                    processInfo = "已杀死PID: $pidInput\n$result"
//                                } else {
//                                    processInfo = "请输入有效的PID"
//                                }
//                            } else {
//                                processInfo = "请先启动Shizuku服务,并授权应用"
//                            }
//                        } catch (e: Exception) {
//                            processInfo = "杀死进程失败: ${e.message}"
//                        }
//                    }
//                },
//                modifier = Modifier.padding(16.dp)
//            ) {
//                Text("杀死进程")
//            }
//        }
        Row(
    modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(vertical = 8.dp)
) {
     // 悬浮赞助按钮
        FloatingActionButton(
            onClick = { showQRDialog = true },
            modifier = Modifier.padding(8.dp)
        ) {
        Text("赞助")
        }
        
        // Shizuku说明按钮
        FloatingActionButton(
            onClick = { showShizukuDialog = true },
            modifier = Modifier.padding(8.dp)
        ) {
        Text("说明")
        }
        
        // 赞助二维码对话框
        if (showQRDialog) {
            AlertDialog(
                onDismissRequest = { showQRDialog = false },
                title = { Text("感谢支持") },
                text = {
                    Column {
                        Text("扫描二维码赞助开发者,邮箱390739790@qq.com")
                        Row {
                            Column(
    modifier = Modifier.fillMaxWidth(),
    horizontalAlignment = Alignment.CenterHorizontally
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id =R.drawable.wx),
                contentDescription = "赞助二维码1",
                modifier = Modifier.size(120.dp)
            )
            Button(
                onClick = { saveImageToGallery(context, R.drawable.wx) },
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("保存二维码")
            }

        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id =R.drawable.zfb),
                contentDescription = "赞助二维码2",
                modifier = Modifier.size(120.dp)
            )
            Button(
                onClick = { saveImageToGallery(context, R.drawable.zfb) },
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("保存二维码")
            }
        }
    }
}
                        }

                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showQRDialog = false }
                    ) {
                        Text("关闭")
                    }
                }
            )
        }

        // Shizuku说明对话框
        if (showShizukuDialog) {
            AlertDialog(
                onDismissRequest = { showShizukuDialog = false },
                title = { Text("软件使用说明v3.0") },
                text = {
                    Column {
                        Text("无需ROOT权限")
                        Text("1. 下载并安装Shizuku应用")
                        Text("2. 启动Shizuku服务")
                        Text("3. 授权本应用使用Shizuku权限")
                        Text("4. 授权后无显示或异常重开本应用即可")
                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            Text("点击下载Shizuku")
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showShizukuDialog = false }
                    ) {
                        Text("关闭")
                    }
                }
            )
        }

        Button(
            onClick = {
                scope.launch {
                    try {
                        if (Shizuku.pingBinder()) {
                            val result = Shizuku.newProcess(arrayOf("ps", "-eo", "pid,user,%cpu,%mem,name", "--sort=-%cpu"), null, null).inputStream.bufferedReader().use { it.readText() }
                            processInfo = result
                        } else {
                            processInfo = "请先启动Shizuku服务,并授权应用"
                        }
                    } catch (e: Exception) {
                        processInfo = "获取CPU信息失败: ${e.message}"
                    }
                }
            },
            modifier = Modifier.padding(16.dp)
        ) {
            Text("显示CPU最高进程")
        }

        Button(
            onClick = {
                scope.launch {
                    try {
                        if (Shizuku.pingBinder()) {
                            val result = Shizuku.newProcess(arrayOf("ps","-eo", "pid,user,%cpu,%mem,name", "--sort=-%mem"), null, null).inputStream.bufferedReader().use { it.readText() }


                            processInfo = result
                        } else {
                            processInfo = "请先启动Shizuku服务,并授权应用"
                        }
                    } catch (e: Exception) {
                        processInfo = "获取内存信息失败: ${e.message}"
                    }
                }
            },
            modifier = Modifier.padding(16.dp)
        ) {
            Text("显示内存最高进程")
        }
        
        Button(
            onClick = {
                scope.launch {
                    try {
                        if (Shizuku.pingBinder()) {
                            val result = Shizuku.newProcess(arrayOf("ps",  "-eo", "pid,user,%cpu,%mem,name", "--sort=pid"), null, null).inputStream.bufferedReader().use { it.readText() }
                            processInfo = result
                        } else {
                            processInfo = "请先启动Shizuku服务,并授权应用"
                        }
                    } catch (e: Exception) {
                        processInfo = "按进程ID排序失败: ${e.message}"
                    }
                }
            },
            modifier = Modifier.padding(16.dp)
        ) {
            Text("按进程ID排序")
        }
        
        Button(
            onClick = {
                scope.launch {
                    try {
                        if (Shizuku.pingBinder()) {
                            val result = Shizuku.newProcess(arrayOf("ps",  "-eo", "pid,user,%cpu,%mem,name", "--sort=user"), null, null).inputStream.bufferedReader().use { it.readText() }
                            processInfo = result
                        } else {
                            processInfo = "请先启动Shizuku服务,并授权应用"
                        }
                    } catch (e: Exception) {
                        processInfo = "按用户排序失败: ${e.message}"
                    }
                }
            },
            modifier = Modifier.padding(16.dp)
        ) {
            Text("按用户排序")
        }
        
        Button(
            onClick = {
                scope.launch {
                    try {
                        if (Shizuku.pingBinder()) {
                            val result = Shizuku.newProcess(arrayOf("ps", "-eo", "pid,user,%cpu,%mem,name", "--sort=cmd"), null, null).inputStream.bufferedReader().use { it.readText() }
                            processInfo = result
                        } else {
                            processInfo = "请先启动Shizuku服务,并授权应用"
                        }
                    } catch (e: Exception) {
                        processInfo = "按命令排序失败: ${e.message}"
                    }
                }
            },
            modifier = Modifier.padding(16.dp)
        ) {
            Text("按命令排序")
        }
        }
        ProcessInfoTable(
            processInfo = processInfo,
            modifier = Modifier
        )
//        Button(
//            onClick = {
//                scope.launch {
//                    try {
//                        if (Shizuku.pingBinder()) {
//                            val result = Shizuku.newProcess(arrayOf("adb", "shell", "getprop"), null, null).inputStream.bufferedReader().use { it.readText() }
//                            processInfo = result
//                        } else {
//                            processInfo = "请先启动Shizuku服务,并授权应用"
//                        }
//                    } catch (e: Exception) {
//                        processInfo = "获取ADB信息失败: ${e.message}"
//                    }
//                }
//            },
//            modifier = Modifier.padding(16.dp)
//        ) {
//            Text("获取ADB设备信息")
//        }

        // 原有的用户列表代码
//        LazyColumn {
//            items(users.size) { index ->
//                UserItem(user = users[index])
//            }
//        }
    }
}

@Composable
fun UserItem(user: User) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Name: ${user.name}")
        Text(text = "Age: ${user.age}")
    }
}

@Preview(showBackground = true)
@Composable
fun UserListPreview() {
    TestTheme {
        UserList(
            context = androidx.compose.ui.platform.LocalContext.current as ComponentActivity
        )
    }
}